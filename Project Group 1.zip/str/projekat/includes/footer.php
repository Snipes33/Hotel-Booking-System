<footer id="bottom">
    <div class="footerGrid">
        <div class="Footer">
            <h4 id="location">Contact </h4>
            <article> hotel@email.com </article>
            <article> + 987 654 321</article>

        </div>



        <div class="Footer">
            <h4>About </h4>
            <p id="about">  From our state-of-the-art amenities to personalized service, this hotel has established itself as a premier choice for travelers seeking a blend of modernity and comfort since its inception.
            </p>

        </div>




        <div class="Footer">
            <h4 id="followUs">Follow Us </h4>
            <a href="https://www.facebook.com/" target="_blank">   <img src="https://w7.pngwing.com/pngs/806/294/png-transparent-facebook-logo-logo-facebook-icon-facebook-logo-brand-social-network-scalable-vector-graphics-thumbnail.png"  alt="Facebook logo" width="35px"> </a>
            <a href="https://www.instagram.com/" target="_blank"> <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/Black_Instagram_icon.svg/2048px-Black_Instagram_icon.svg.png" alt="Instagram logo" width="35px"> </a>
            <a href="https://www.twitter.com/" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/60/60580.png" alt="Twitter logo" width="35px"> </a>

        </div>
    </div>
</footer>